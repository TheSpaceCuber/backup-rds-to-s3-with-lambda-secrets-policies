import csv
import pymysql
import boto3
import tempfile
import os 
import logging
import zipfile

# s3 settings
S3_BUCKET = 'rds-backup-1-test'
S3_KEY = 'backup.zip'

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, 
                           db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")
    
def lambda_handler(event, context):
    """
    This function creates a new RDS database table and writes records to it
    """
    cur = conn.cursor()
    cur.execute("""use `cloudtrain`;""")
    cur.execute("""SELECT * FROM employee""")
    query_results = cur.fetchall()
    
    # Create a temporary directory to store the CSV file
    temp_dir = tempfile.mkdtemp()
    
    # Create the CSV file in the temporary directory
    csv_filename = f"{temp_dir}/data.csv"
    with open(csv_filename, 'w', newline='') as csv_file:
        csv_writer = csv.writer(csv_file)
        # Write data to CSV file
        for row in query_results:
            csv_writer.writerow(row)

    # Create a zip archive with the CSV file
    with tempfile.NamedTemporaryFile(delete=False) as zip_file:
        with zipfile.ZipFile(zip_file, 'w') as zipf:
            zipf.write(csv_filename, 'data.csv')

    # Upload the zip archive to S3
    s3 = boto3.client('s3', region_name='ap-southeast-1')
    s3.upload_file(csv_filename, S3_BUCKET, S3_KEY)

    # Clean up the temporary files and directory
    os.remove(csv_filename)
    os.remove(zip_file.name)
    os.rmdir(temp_dir)

    return "Backup completed successfully"

    
    
